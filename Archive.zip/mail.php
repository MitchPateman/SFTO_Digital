<?php
// add your email address here
define("CONTACT_FORM", 'http://formspree.io/mitchell.pateman@gmail.com');
?>
